<?php

include('db.php');
session_start();
$i=1;

if(isset($_POST['submit']))
{   





	 

	 

	 



	 $q_no = $_POST['q_no'];
	 $value = $_POST['radio'];

	 $answer_data = "INSERT INTO student (q_no,answer_no,result) VALUES ('$q_no','$value','Wrong')";
	 $run_answer_data = mysqli_query($con,$answer_data);

	 if($run_answer_data){
	 	
	 }else{
	 	echo "not insert";
	 }
	
	 

	 $count = $_POST['count'];
	 $i = $q_no+1;



	 if($i == $count+1){

	 	header('location:finish.php');
	 }

	    

		
	 

}




?>




<!DOCTYPE html>
<html>
<head>
	<title>MCQ System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-12">
				<form method="post" action="">
					<?php

					     $total_data = "SELECT * FROM question";
					     $run_data = mysqli_query($con,$total_data);
					     $count = mysqli_num_rows($run_data);
					    
					     $get_data = "SELECT * FROM question WHERE id = $i ";
					     $run_data = mysqli_query($con,$get_data);
					     


					     

					     while($row = mysqli_fetch_array($run_data))
					     {

					     	

					     	$question = $row['question'];
					     	$id = $row['id'];
					     	$c1 = $row['c1'];
					     	$c2 = $row['c2'];
					     	$c3 = $row['c3'];
					     	$c4 = $row['c4'];
					     	echo "
					     	  <h4 style='font-weight: bold'>$id.out of $count</h4>
					     	  <br>
					     	  <br>
					     	  <br>
					     	  <h4 style='font-weight: bold'>$id.$question</h4>
					     	  <label class='container'>
                                     <input type='radio' checked='checked' name='radio' value='1'> $c1
                                     <span class='checkmark'></span>
                               </label>

                               <label class='container'>
                                     <input type='radio'  name='radio' value='2'> $c2
                                     <span class='checkmark'></span>
                               </label>

                               <label class='container'>
                                     <input type='radio'  name='radio' value = '3'> $c3
                                     <span class='checkmark'></span>
                               </label>

                               <label class='container'>
                                     <input type='radio'  name='radio' value='4'> $c4
                                     <span class='checkmark'></span>
                               </label>

                               <input type='hidden' name='q_no' value='$id'>
                               <input type='hidden' name='count' value='$count'>
                               <input type='submit' name='submit' class='btn btn-primary' value='Submit'>
					
					     	  ";
					     	

					     	  
					     }


					?>
					
					
                    
                    
				</form>
			</div>
		</div>
	</div>

</body>
</html>