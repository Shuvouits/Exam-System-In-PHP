<?php

include('db.php');
$get_question_data = "SELECT * FROM question";
$run_question_data = mysqli_query($con,$get_question_data);
$i=1;


while($row = mysqli_fetch_array($run_question_data))
{
	$answer = $row['answer'];
	$id = $row['id'];
	
	
	$get_student_data = "SELECT * FROM student WHERE q_no =$id AND answer_no = $answer ";
	$run_student_data = mysqli_query($con,$get_student_data);
	//$count = mysqli_num_rows($run_student_data);

	
		while($row1=mysqli_fetch_array($run_student_data))
	 {
		$q_no = $row1['q_no'];

		$update_student_data = "UPDATE student SET result='Right', mark='2' WHERE q_no = $q_no ";
		$run_data = mysqli_query($con,$update_student_data);

		
	 }







	
	

}






?>


<!DOCTYPE html>
<html>
<head>
	<title>MCQ System</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row jumbotron">
			<div class="col-md-12">

				<div class="col-md-2">
					<a href="index.php" class="btn btn-primary ">Home</a>
				</div>
				<div class="col-md-6">
					<h4 class="text-center" style="font-weight: bold">Finished Your Exam!</h4>
				</div>
				<div class="col-md-4">
					<?php
					   $get_data = "SELECT * ";

					?>
					<h4 class="text-center" style="font-weight: bold">
					     <?php
					         $get_data_mark = "SELECT * FROM student";
					         $run_data_mark = mysqli_query($con,$get_data_mark);
					         $total = 0;

					         while($row = mysqli_fetch_array($run_data_mark))
					         {
					         	$mark = $row['mark'];
					         	$total = $total+$mark;
					         }

					         echo "Your Total Number = $total";

					     ?>
					 </h4>
				</div>
				
			</div>
			<br>
			<br>
			<br>
			<div class="col-md-12 text-center">
				<table class="table table-bordered table-striped table-hover">
					<thead>
						<tr>
							<th class="text-center">NO</th>
							<th class="text-center">Question</th>
							<th class="text-center">Result</th>
							<th class="text-center">Mark</th>
							

						</tr>
					</thead>
					<tbody>
						<?php

						$get_data_question = "SELECT * FROM question";
						$run_data = mysqli_query($con,$get_data_question);

						while($row = mysqli_fetch_array($run_data))
						{
							$question = $row['question'];
							$id=$row['id'];
							$correct_answer = $row['correct_answer'];

							

							echo "

							<tr>
							     <td class='text-center'>$id</td>
							     <td class='text-center'>$question</td>
							";

							$get_data_student = "SELECT * FROM student WHERE q_no=$id ";
							$run_data_student = mysqli_query($con,$get_data_student);

							while($row1 = mysqli_fetch_array($run_data_student))
							{
								$result = $row1['result'];
								$mark = $row1['mark'];

								echo "<td class='text-center'>$result</td>";

							}

							

							
							 echo "  

							  <td class='text-center'>$mark</td>

							     
						    </tr>


							";

						}

						?>
						
					</tbody>
				</table>
				
				
			</div>
		</div>
	</div>

</body>
</html>