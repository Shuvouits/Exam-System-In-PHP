<?php

$con = mysqli_connect('localhost','root','','test');

if($con){

}else{
	echo "Not Connected";
}


?>